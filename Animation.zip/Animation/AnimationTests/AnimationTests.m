//
//  AnimationTests.m
//  AnimationTests
//
//  Created by Benny on 7/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AnimationTests.h"


@implementation AnimationTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in AnimationTests");
}

@end
