//
//  AnimationTests.h
//  AnimationTests
//
//  Created by Benny on 7/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface AnimationTests : SenTestCase {
@private
    
}

@end
