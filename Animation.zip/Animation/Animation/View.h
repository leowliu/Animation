//
//  View.h
//  Animation
//
//  Created by Benny on 7/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface View : UIView {
    UIView *view;
    UIImageView *imageView;
}

@end
