//
//  AnimationAppDelegate.h
//  Animation
//
//  Created by Benny on 7/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class View;

@interface AnimationAppDelegate : NSObject <UIApplicationDelegate> {
    View *view;
    UIWindow *_swindow;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
